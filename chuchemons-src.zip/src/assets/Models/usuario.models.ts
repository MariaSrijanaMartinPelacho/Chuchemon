export interface usuario {
    nick?: string;
    email?: string;
    contrasena?: string;
    rol?: string;
  }

  
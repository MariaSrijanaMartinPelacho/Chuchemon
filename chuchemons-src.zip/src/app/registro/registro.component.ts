import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserServicesService } from '../services/user-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  formRegister: FormGroup;

  constructor(private userService: UserServicesService, private fb: FormBuilder, private router: Router) {
    this.formRegister = this.fb.group({
      nick: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contrasena: ['', Validators.required],
      confirmarContrasena: ['', Validators.required],
      rol: ['', Validators.required]
    });
  }

  registrarUsuario() {
    if (this.formRegister.valid) {

      const contrasenaControl = this.formRegister.get('contrasena');
    const confirmarContrasenaControl = this.formRegister.get('confirmarContrasena');

    if (contrasenaControl && confirmarContrasenaControl) {
      const contrasena = contrasenaControl.value;
      const confirmarContrasena = confirmarContrasenaControl.value;

      if (contrasena !== confirmarContrasena) {
        alert("Las contraseñas no coinciden.");
        return;
      }

      console.log(this.formRegister.value);

      this.userService.registroUser(this.formRegister.value).subscribe({
        next: value => {
          console.log(value);
          this.router.navigate(['/Login']);
          alert("Usuario registrado correctamente");
        },
        error: err => alert("Error en el registro: " + err)
      });
    }
  }
}

}

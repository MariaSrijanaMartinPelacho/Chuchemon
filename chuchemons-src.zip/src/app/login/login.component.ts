import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserServicesService } from '../services/user-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  formLogin: FormGroup;

  constructor(private userService: UserServicesService, private fb: FormBuilder, private router: Router) {
    this.formLogin = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      contrasena: ['', Validators.required]
    });
  }

  iniciarSesion() {
    if (this.formLogin.valid) {
      console.log(this.formLogin.value);

      this.userService.loginUser(this.formLogin.value).subscribe({
        next: value => {
          console.log(value);
          if (this.formLogin.value.email === 'admin@gmail.com' && this.formLogin.value.contrasena === 'administrador') {
            this.router.navigate(['/vista-admin']);
          } else {
            this.router.navigate(['/menuvista']);
          }
          alert("Inicio de sesión exitoso");
        },
        error: err => alert("Error al iniciar sesión: " + err)
      });
    }
  }
}

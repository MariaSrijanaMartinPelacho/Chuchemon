import { Injectable } from '@angular/core';
import {catchError, map, Observable} from "rxjs";
import {HttpClient, HttpHeaders, HttpParams} from "@angular/common/http";
import {of} from "rxjs";
import {tap} from "rxjs/operators";
import { Router } from '@angular/router';
import { Usuario } from '../Models/usuario.model';

@Injectable({
  providedIn: 'root'
})

export class UserServicesService {

  constructor(private http: HttpClient, private router: Router) { }

  registroUser(formdatas:any){
    const nick=formdatas.nick;
    const correo=formdatas.email;
    const contrasena=formdatas.contrasena;
    const rol=formdatas.rol;
    return this.http.post('http://127.0.0.1:8000/api/create?nick='+nick+'&correo='+correo+'&contrasena='+contrasena+'&rol='+rol,{})
  }
  
  loginUser(loginUser: any) {
    const correo = loginUser.email;
    const contrasena = loginUser.contrasena;
    //this.router.navigate(['/main-page']);
    return this.http.post('http://127.0.0.1:8000/api/login', { correo, contrasena });
  }

  getAllData() {
    return this.http.get<any[]>('http://127.0.0.1:8000/api/select');
  }
}

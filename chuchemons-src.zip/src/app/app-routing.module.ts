import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistroComponent } from './registro/registro.component';
import { LoginComponent } from './login/login.component';
import { XuxemonsComponent } from './xuxemons/xuxemons.component';
import { MenuComponent } from './menu/menu.component';
import { MenuvistaComponent } from './menuvista/menuvista.component';
import { VistaAdminComponent } from './vista-admin/vista-admin.component';
import { CardComponent } from './card/card.component';

const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'Registro'},
  {
    path: 'Registro',
    component: RegistroComponent
  },
  {
    path: 'Login',
    component: LoginComponent
  },
  {
    path: 'Xuxemons',
    component: XuxemonsComponent
  },
  {
    path: 'menu',
    component: MenuComponent
  },
  {
    path: 'menuvista',
    component: MenuvistaComponent
  },
  {
    path: 'vista-admin',
    component: VistaAdminComponent
  },
  {
    path: 'card',
    component: CardComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
}) export class AppRoutingModule { }

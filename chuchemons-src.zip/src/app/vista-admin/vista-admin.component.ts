import { Component } from '@angular/core';
import { UserServicesService } from '../services/user-services.service';

@Component({
  selector: 'app-vista-admin',
  templateUrl: './vista-admin.component.html',
  styleUrls: ['./vista-admin.component.css']
})
export class VistaAdminComponent {
  datos: any[];

  constructor(private userService: UserServicesService) { }

  ngOnInit(): void {
    this.userService.getAllData().subscribe(data => {
      this.datos = data;
    });
  }
}



export interface Ficha {
    imagen: string;
    nombre: string;
    tipo: string;
    color: string;
  }
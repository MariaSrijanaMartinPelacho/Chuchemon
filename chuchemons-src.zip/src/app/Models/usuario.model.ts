export interface Usuario{
    email: string;
    contrasena: string;
    nick: string;

  }
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LogicaComponent } from './logica/logica.component';
import { Ficha } from './Models/ficha.model';
import { Menu } from './Models/menu';
import { XuxemonsComponent } from './xuxemons/xuxemons.component';
import { RegistroComponent } from './registro/registro.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { MenuComponent } from './menu/menu.component';
import { MenuvistaComponent } from './menuvista/menuvista.component';
import { LoginComponent } from './login/login.component';
import { VistaAdminComponent } from './vista-admin/vista-admin.component';
import { CardComponent } from './card/card.component';

@NgModule({
  declarations: [
    AppComponent,
    LogicaComponent,
    LoginComponent,
    XuxemonsComponent,
    RegistroComponent,
    MenuComponent,
    MenuvistaComponent,
    VistaAdminComponent,
    CardComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component } from '@angular/core';
import { Ficha } from './Models/ficha.model';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'XuchemonProyectoAngular';
  // constructor(
  //   private userService: UsersService,
  // ) {
  // }
  // this.userService.getUsuarios().subscribe({});
}

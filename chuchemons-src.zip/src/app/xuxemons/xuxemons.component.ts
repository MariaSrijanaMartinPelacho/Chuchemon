import { Component } from '@angular/core';
import { Ficha } from '../Models/ficha.model';
import datos from '../../assets/datos.json';

@Component({
  selector: 'app-xuxemons',
  templateUrl: './xuxemons.component.html',
  styleUrls: ['./xuxemons.component.css']
})
export class XuxemonsComponent {
  tarjetas: Ficha[] = [];
  ficha: any;
  logica: Ficha;

  ngOnInit() {
    const json = datos as unknown;
    this.tarjetas = json as Ficha[];
  }
  chuche: any = datos;
}

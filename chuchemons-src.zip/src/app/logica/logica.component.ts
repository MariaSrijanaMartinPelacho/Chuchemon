import { Component,Input } from '@angular/core';
import { Ficha } from '../Models/ficha.model';

@Component({
  selector: 'app-logica',
  templateUrl: './logica.component.html',
  styleUrls: ['./logica.component.css']
})
export class LogicaComponent {
@Input()logica:Ficha;
}

import { Component, OnInit } from '@angular/core';
import { CardService } from '../services/card.service';
import { Ficha } from '../Models/ficha.model';
import datos from '../../assets/datos.json';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],
})
export class CardComponent implements OnInit {
  randomCard: any;
  tarjetas: Ficha[] = [];
  ficha: any;
  logica: Ficha;

  constructor(private cardService: CardService) {}

  ngOnInit() {
    this.loadRandomCard();
    const json = datos as unknown;
    this.tarjetas = json as Ficha[];
  }

  loadRandomCard() {
    this.cardService.getCards().subscribe((datos) => {
      const randomIndex = Math.floor(Math.random() * datos.length);
      this.randomCard = datos[randomIndex];
    });
  }
}

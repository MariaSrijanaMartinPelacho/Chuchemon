import { Component } from '@angular/core';
import { Menu } from '../Models/menu';
import menu from '../../assets/menu.json';

@Component({
  selector: 'app-menuvista',
  templateUrl: './menuvista.component.html',
  styleUrls: ['./menuvista.component.css']
})
export class MenuvistaComponent {
  tarjetas: Menu[] = [];
  ficha: any;
  menu: Menu;

  ngOnInit() {
    const json = menu as unknown;
    this.tarjetas = json as Menu[];
  }
  chuche: any = menu;
}

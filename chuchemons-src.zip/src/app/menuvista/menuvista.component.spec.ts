import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuvistaComponent } from './menuvista.component';

describe('MenuvistaComponent', () => {
  let component: MenuvistaComponent;
  let fixture: ComponentFixture<MenuvistaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MenuvistaComponent]
    });
    fixture = TestBed.createComponent(MenuvistaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
